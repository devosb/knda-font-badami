README
NLCI Kannada fonts
==================

Thank you for your interest in NLCI's Kannada fonts.

NLCI's Kannada fonts are released under the SIL Open Font License.

See the OFL and OFL-FAQ for details of the SIL Open Font License.
See the FONTLOG for information on this and previous releases.
